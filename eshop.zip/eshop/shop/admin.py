from django.contrib import admin
from .models import CustomUser,Profile,Product,Category,Order


# Register your models here.
@admin.register(CustomUser)
class PostModelAdmin(admin.ModelAdmin):
 list_display = ['id', 'email', 'password','first_name','last_name','address']


@admin.register(Profile)
class PostModel(admin.ModelAdmin):
 list_display = ['user', 'auth_token', 'is_verified','created_at']


@admin.register(Product)
class Product(admin.ModelAdmin):
 list_display = ['name', 'price','description','image','category']

@admin.register(Category)
class category(admin.ModelAdmin):
 list_display = ['name',]
admin.site.register(Order)






