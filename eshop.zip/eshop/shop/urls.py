from django.contrib import admin
from django.urls import path
from .views import *
from django.conf import settings
from django.conf.urls .static import static

urlpatterns = [
    path('',home.as_view(),name='home'),
    path('register' , register_attempt , name="register_attempt"),
    path('accounts/login/' , login_attempt , name="login_attempt"),
    path('token' , token_send , name="token_send"),
    path('success' , success , name='success'),
    path('verify/<auth_token>' , verify , name="verify"),
    path('error' , error_page , name="error"),
    path('log' , user_logout , name="log"),
    path('cart/',Cart.as_view(),name="cart"),
    path('nandan',CheckOut.as_view(),name="nandan"),
    path('nandan',CheckOut.as_view(),name="nandan"),
     path('ord/',OrderView.as_view(),name="order")




    


    
   
]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
