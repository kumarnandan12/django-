from django.contrib import admin
from app.models import Image
from app.models import Item
from app.models import Bid


admin.site.register(Image)
admin.site.register(Item)
admin.site.register(Bid)

