
from urllib import response
from django.shortcuts import render, HttpResponseRedirect,redirect
from .forms import   SignUpForm, LoginForm,InputForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from .models import Image
from .models import Item
from .models import Image
from .models import Bid
from django.contrib.auth.models import User
def home(request):
  img=Image.objects.all()
  instance=Image.objects.all()
  return render(request, 'blog/home.html',{'img':img,'instance':instance})
def dashboard(request):
 if request.user.is_authenticated:
  it=Item.objects.all()
  
  user = request.user
  full_name = user.get_full_name()
  
  return render(request, 'blog/dashboard.html', { 'full_name':full_name,'it':it })
 else:
  return HttpResponseRedirect('/login/')
def user_logout(request):
 logout(request)
 return HttpResponseRedirect('/')
def user_signup(request):
 if request.method == "POST":
  form = SignUpForm(request.POST)
  if form.is_valid():
   messages.success(request, 'Congratulations!! You have successfully Sign up.')
   user = form.save()
   return HttpResponseRedirect('/login/')  
 else:
  form = SignUpForm()
 return render(request, 'blog/signup.html', {'form':form})


def user_login(request):
 form=""
 if not request.user.is_authenticated:
  if request.method == "POST":
   form = LoginForm(request=request, data=request.POST)
   if form.is_valid():
    uname = form.cleaned_data['username']
    upass = form.cleaned_data['password']
    user = authenticate(username=uname, password=upass)
    if user is not None:
      if(user.is_superuser):
       data=User.objects.all()
       data1=Bid.objects.all()
       login(request,user)
       return render(request,'blog/admin.html',{'data':data,'data1':data1})
      else:
       login(request,user)
       messages.success(request, 'Logged in Successfully !!')
       return HttpResponseRedirect('/dashboard/')

  else:
    form = LoginForm()
  return render(request, 'blog/login.html', {'form':form})
 else:
  return HttpResponseRedirect('/dashboard/')
 
def bid(request):
 if request.method == "POST":
   form = InputForm(request.POST)
   if form.is_valid():
    nm=form.cleaned_data['name']
    pm=form.cleaned_data['productid']
    am=form.cleaned_data['maxamount']
    usr=request.user.username
    bidexist=Bid.objects.filter(Bidder=usr).first()
    if bidexist:
     bidexist.maxamount=am
     bidexist.save()
    else: 
     reg=Bid(Bidder=nm,productid=pm,maxamount=am) 
     reg.save()
    messages.success(request, 'Congratulations!! Your Bid Apply successfully.')
    return HttpResponseRedirect('/dashboard/')
 else:
  form = InputForm()
 return render(request, 'blog/signup.html', {'form':form } )

def winner(request):
 bids=Bid.objects.all()
 it=Item.objects.all()
 if bids:
   winner=max(bids,key=lambda bid:bid.maxamount)
   return render(request,'blog/winner.html',{'winner':winner,'it':it })

   

    

    
  

 






