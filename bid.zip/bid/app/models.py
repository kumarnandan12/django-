from distutils.command.upload import upload
from django.db import models
class Image(models.Model):
   photo=models.ImageField(upload_to="mypic")
   date = models.DateTimeField(auto_now_add=True)   
class Item(models.Model):
   photo=models.ImageField(upload_to="pic")
   time=models.TimeField()
   productid=models.IntegerField(max_length=20)
   description=models.TextField(null=True)
class Bid(models.Model):
   Bidder=models.CharField(max_length=20)
   maxamount=models.IntegerField(max_length=24)
   productid=models.IntegerField(max_length=30 ,null=True)
   
   

   



        



    


