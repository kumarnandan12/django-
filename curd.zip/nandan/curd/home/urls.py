from django.urls import path
from home import views
urlpatterns = [
    path('' ,views.home),
    path('home/',views.home),
    path('addstudent/', views.addstudent),
    path('deletestudent/<int:roll>',views.deletestudent),

    path('updatestudent/<int:roll>',views.updatestudent),
    path('doupdatestudent/<int:roll>',views.doupdatestudent)


    
]
