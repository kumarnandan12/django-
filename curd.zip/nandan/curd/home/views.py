from django.shortcuts import render, redirect
from .models import Student
def home(request):
    data=Student .objects.all()
    return render(request,"home.html",{'stu':data})


def addstudent(request)  :
    if request.method=='POST':
        sturoll=request.POST.get("roll")
        stuname=request.POST.get("name")
        stuemail=request.POST.get("email")
        stuaddress=request.POST.get("address")
        stuphone=request.POST.get("phone")
        s=Student()
        s.roll=sturoll
        s.name=stuname
        s.email=stuemail
        s.address=stuaddress
        s.phone=stuphone
        
        s.save()
        return redirect("/home/")
    
    return render(request,"add.html")  

def deletestudent(request,roll) :
    s=Student.objects.get(pk=roll)
    s.delete()

    return redirect("/home")
def updatestudent(request,roll):
    stu=Student.objects.get(pk=roll)
    return render(request ,"update.html",{'stu':stu})

def doupdatestudent(request,roll):
    
        sturoll=request.POST.get("roll")
        stuname=request.POST.get("name")
        stuemail=request.POST.get("email")
        stuaddress=request.POST.get("address")
        stuphone=request.POST.get("phone")
        std=Student.objects.get(pk=roll)  
        std.roll=sturoll
        std.name=stuname
        std.email=stuemail
        std.address=stuaddress
        std.phone=stuphone
        std.save()
        
        return redirect('/home/')
        










